import wave

# Combat Beneath the Waves
# Time Signature: 6/8
# 120BPM
# All notes I use will be 1/4 of a bar, or 1/6th of a bar

secret = "I_L0V3-GENSH1n"

notes = {
	"A": "./audio/65.wav",
	"B": "./audio/53.wav",
	"C": "./audio/2.wav",
	"D": "./audio/27.wav",
	"E": "./audio/1.wav",
	"F": "./audio/61.wav",
	"G": "./audio/6.wav",
	"H": "./audio/46.wav",
	"I": "./audio/39.wav",
	"J": "./audio/20.wav",
	"K": "./audio/59.wav",
	"L": "./audio/46.wav",
	"M": "./audio/8.wav",
	"N": "./audio/39.wav",
	"O": "./audio/19.wav",
	"P": "./audio/73.wav",
	"Q": "./audio/33.wav",
	"R": "./audio/58.wav",
	"S": "./audio/42.wav",
	"T": "./audio/5.wav",
	"U": "./audio/4.wav",
	"V": "./audio/48.wav",
	"W": "./audio/32.wav",
	"X": "./audio/37.wav",
	"Y": "./audio/69.wav",
	"Z": "./audio/72.wav",
	"a": "./audio/17.wav",
	"b": "./audio/21.wav",
	"c": "./audio/63.wav",
	"d": "./audio/36.wav",
	"e": "./audio/51.wav",
	"f": "./audio/31.wav",
	"g": "./audio/35.wav",
	"h": "./audio/43.wav",
	"i": "./audio/12.wav",
	"j": "./audio/54.wav",
	"k": "./audio/40.wav",
	"l": "./audio/67.wav",
	"m": "./audio/52.wav",
	"n": "./audio/48.wav",
	"o": "./audio/16.wav",
	"p": "./audio/71.wav",
	"q": "./audio/23.wav",
	"r": "./audio/22.wav",
	"s": "./audio/9.wav",
	"t": "./audio/15.wav",
	"u": "./audio/41.wav",
	"v": "./audio/57.wav",
	"w": "./audio/38.wav",
	"x": "./audio/62.wav",
	"y": "./audio/55.wav",
	"z": "./audio/18.wav",
	"0": "./audio/49.wav",
	"1": "./audio/49.wav",
	"2": "./audio/25.wav",
	"3": "./audio/44.wav",
	"4": "./audio/3.wav",
	"5": "./audio/11.wav",
	"6": "./audio/13.wav",
	"7": "./audio/50.wav",
	"8": "./audio/24.wav",
	"9": "./audio/70.wav",
	"-": "./audio/10.wav",
	"_": "./audio/42.wav",
	"!": "./audio/66.wav",
	"@": "./audio/30.wav",
	"#": "./audio/34.wav",
	"$": "./audio/26.wav",
	"%": "./audio/29.wav",
	"^": "./audio/45.wav",
	"&": "./audio/14.wav",
	".": "./audio/7.wav",
	"(": "./audio/60.wav",
	")": "./audio/47.wav",
}

data = []

for char in secret:
	w = wave.open(notes[char], "rb")
	data.append([w.getparams(), w.readframes(w.getnframes())])
	w.close()

encoded = wave.open("secret.wav", 'wb')
encoded.setparams(data[0][0])
for i in range(len(data)):
    encoded.writeframes(data[i][1])
encoded.close()
